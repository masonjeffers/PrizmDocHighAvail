var config = require('./config.json');
var request = require('request');

var HAProxyHandler = require('./haProxyHandler.js');
var haProxy = new HAProxyHandler();

console.log("Updater started...");

setInterval(() => {
	console.log("Checking List");
	haProxy.requestServerList()
		.then((data) => {
			updateList(data);
		}
	);
}, config["updateInterval"]);

function updateList(newList) {
	var data = [];
	newList.forEach(function(value) {
		data.push({
			"address": value,
			"port": config["SEP"]
		});
	});
	data = {"servers": data};	
	console.log("Pushing new list: " + JSON.stringify(data));
	newList.forEach(function(value) {
		request({
			url: 'http://' + value + ':' + config["CEP"] + '/PCCIS/V1/Service/Properties/Servers',
			body: data,
			json: true,
			method: 'put'
		}, function(error, response, body) {
			if (error) {
				console.log(error);
			}
			// console.log(response);
		});
	});	
}
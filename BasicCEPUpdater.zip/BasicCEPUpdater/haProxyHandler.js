'use strict';

const parseCsv = require('neat-csv');
const request = require('request');
const ipValidator = require('ip-address').Address4;
const config = require('./config.json');
const Promise = require('bluebird');

function HAProxyHandler() {}

function requestLoadBalancerCsv() {
  return new Promise((resolve, reject) => {
    let reqOptions = {
      'auth': {
        'user': config.haProxyUserName,
        'pass': config.haProxyPass,
        'sendImmediately': false
      },  
      url: `${config.haProxyStatsUrl};csv`,
    }
	
    request(reqOptions, (error, response, body) => {
	  if (response.statusCode !== 200) {
	    return reject(error);
	  }
      return resolve(body);
    });
  })
}

function isValidIP(address) {
  const serverIp = new ipValidator(address);
  return serverIp.isValid();
}

function isServerHealthy(server) {
  return new Promise((resolve, reject) => {
      let serverName = server.svname;
      let serverStatus = server.status.toLowerCase();

	  if (!isValidIP(serverName) || serverStatus !== 'up') {
		return resolve();
      }
	  return resolve(serverName);
  });
}

function checkServerData(csvData) {
  let promiseArray = csvData.map(isServerHealthy);
  return Promise.filter(promiseArray, (item) => { return item !== undefined } );
}

HAProxyHandler.prototype.requestServerList = function requestServerList() {
  return requestLoadBalancerCsv()
    .then(parseCsv)
    .then(checkServerData)
    .then((healthyServerList) => healthyServerList)
    .catch((err) => { console.log(err) });
} 

module.exports = HAProxyHandler;